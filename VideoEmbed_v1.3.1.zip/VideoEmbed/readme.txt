[size=x-large][b]Video Embed[/b][/size]

A modification for SMF 2.1 that expands support for embedding videos from video hosting sites.

Supported video hosting sites include:
[list]
[li]YouTube[/li]
[li]Vimeo[/li]
[li]RuTube[/li]
[li]Locally hosted video and audio files[/li]
[/list]

BBCodes are added for each of the supported video hosting sites.

SMF's default YouTube editor toolbar button is replaced with a generic Video button that will automatically detect video URLs from the supported video hosting sites.

Future versions of this modification may expand support to include other video hosting sites, but I promise you nothing.

This modification is also backward compatible with BBCodes created by several older YouTube and Vimeo modifications. So if you previously used a modification to add YouTube or Vimeo support to SMF 2.0.x and then upgraded your forum to SMF 2.1.x, this modification [i]might[/i] fix any broken embed codes in your pre-existing posts. (Note: BBCode parameters from older modifications may be ignored.)


[size=large][b]Settings[/b][/size]

There are no settings. Install to enable, uninstall to disable.


[size=large][b]License[/b][/size]

Video Embed is released under the MIT License. A full copy of this license is included in the package file.


[size=large][b]Changelog[/b][/size]

Version 1.3:
[list]
	[li]Added support RuTube URLs by Vladimir 'siborg' Saenko (FMFan.ru).[/li]
[/list]

Version 1.2:
[list]
	[li]Avoids "Undefined index: host" error when processing malformed YouTube URLs.[/li]
[/list]

Version 1.1:
[list]
	[li]Expands backward compatibility support for old YouTube mods that used the form [nobbc]https://youtu.be/4vuW6tQ0218[/nobbc].[/li]
[/list]

Version 1.0:
[list]
	[li]Initial release[/li]
[/list]