/*******************************************************************************
 * Video Embed
 *
 * A modification for SMF 2.1 that expands support for embedding videos from
 * video hosting sites.
 *
 * Copyright (c) 2023 Jon Stovell
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 ******************************************************************************/

// Support Vimeo embeds in the editor.
sceditor.formats.bbcode.set("vimeo", {
  allowsEmpty: false,
  tags: {
    div: {
      class: "videocontainer",
    },
  },
  isInline: false,
  skipLastLineBreak: true,
  format: function (element, content) {
    var vimeo_id = $(element).find("iframe").data("vimeo-id");

    if (typeof vimeo_id !== "undefined")
      return "[vimeo]" + vimeo_id + "[/vimeo]";
    else return content;
  },
  html: function (token, attrs, content) {
    if (content === "" || typeof content === "undefined") return "";

    return (
      ' <div class="videocontainer"><div><iframe frameborder="0" src="https://player.vimeo.com/video/' +
      content +
      '?title=0&amp;byline=0&amp;autopause=0&amp;badge=0" data-vimeo-id="' +
      content +
      '" loading="lazy" allowfullscreen style="background-color: black;"></iframe></div></div> '
    );
  },
});

// Support RuTube embeds in the editor.
sceditor.formats.bbcode.set("rutube", {
  allowsEmpty: false,
  tags: {
    div: {
      class: "videocontainer",
    },
  },
  isInline: false,
  skipLastLineBreak: true,
  format: function (element, content) {
    var rutube_id = $(element).find("iframe").data("rutube-id");

    if (typeof rutube_id !== "undefined")
      return "[rutube]" + rutube_id + "[/rutube]";
    else return content;
  },
  html: function (token, attrs, content) {
    if (content === "" || typeof content === "undefined") return "";

    return (
      ' <div class="videocontainer"><div><iframe frameborder="0" src="https://rutube.ru/play/embed/' +
      content +
      '?title=0&amp;byline=0&amp;autopause=0&amp;badge=0" data-rutube-id="' +
      content +
      '" loading="lazy" allowfullscreen style="background-color: black;"></iframe></div></div> '
    );
  },
});

// Support raw video embeds in the editor.
sceditor.formats.bbcode.set("video", {
  allowsEmpty: false,
  tags: {
    div: {
      class: "videocontainer",
    },
  },
  isInline: false,
  skipLastLineBreak: true,
  breakAfter: true,
  format: function (element, content) {
    var video_src = $(element).find("video").attr("src");

    if (typeof video_src !== "undefined")
      return "[video]" + video_src + "[/video]";
    else return content;
  },
  html: function (token, attrs, content) {
    if (content === "" || typeof content === "undefined") return "";

    return (
      '<div class="videocontainer"><video controls preload="metadata" src="' +
      content +
      '" playsinline style="background-color: black; max-width: 100%;"></video></div>'
    );
  },
});

// Support raw audio embeds in the editor.
sceditor.formats.bbcode.set("audio", {
  allowsEmpty: false,
  tags: {
    audio: null,
  },
  isInline: false,
  skipLastLineBreak: true,
  breakAfter: true,
  format: function (element, content) {
    var audio_src = $(element).attr("src");

    if (typeof audio_src !== "undefined")
      return "[audio]" + audio_src + "[/audio]";
    else return content;
  },
  html: function (token, attrs, content) {
    if (content === "" || typeof content === "undefined") return "";

    return (
      '<audio controls preload="none" src="' +
      content +
      '" class="bbc_audio" style="vertical-align: middle; max-width: 100%; width: 400px;"></audio>'
    );
  },
});

// Support 'yt' in the editor, and automatically correct it to 'youtube'.
sceditor.formats.bbcode.set("yt", sceditor.formats.bbcode.get("youtube"));

// Add a generic "Insert Video" button to the editor toolbar.
sceditor.command.set("video", {
  _dropDown: function (editor, caller, callback) {
    var content = document.createElement("div");

    content.innerHTML =
      '<div><label for="video_link">' +
      editor._("Video URL:") +
      '</label> <input type="text" id="video_link" dir="ltr" placeholder="https://" /></div><div><input id="video_insert" type="button" class="button" value="' +
      editor._("Insert") +
      '" /></div>';

    editor.createDropDown(caller, "insertlink", content);

    $("#video_insert").click(function (e) {
      callback($("#video_link").get(0).value);

      editor.closeDropDown(true);
      e.preventDefault();
    });
  },
  exec: function (caller) {
    var editor = this;

    editor.commands.video._dropDown(editor, caller, function (url) {
      var urlMatch;

      // Check for video file URLs.
      urlMatch = url.match(/\.(3gp|m4v|m4p|mp4|mpeg|mpg|mov|ogg|ogv|webm)$/);

      if (urlMatch) {
        editor.insert("[video]" + url + "[/video]");
        return;
      }

      // Check for audio file URLs.
      urlMatch = url.match(/\.(aac|flac|m4a|mp3|oga|wav)$/);

      if (urlMatch) {
        editor.insert("[audio]" + url + "[/audio]");
        return;
      }

      // Check for YouTube URLs.
      urlMatch = url.match(/https?:\/\/[^\/]*\b(?:youtube\.com|youtu\.be)\//);

      if (urlMatch) {
        urlMatch = url.match(
          /(?:v=|v\/|embed\/|youtu.be\/)?([a-zA-Z0-9_-]{11})/
        );

        if (urlMatch) {
          editor.insert("[youtube]" + urlMatch[1] + "[/youtube]");
        } else {
          editor.insert(url);
        }

        return;
      }

      // Check for Vimeo URLs.
      urlMatch = url.match(
        /https?:\/\/[^\/]*\bvimeo\.com\/(?:[^\/\d]*\/)?(\d+)/
      );

      if (urlMatch) {
        editor.insert("[vimeo]" + urlMatch[1] + "[/vimeo]");
        return;
      }

      // Check for RuTube URLs. ---------------------------------------/
      urlMatch = url.match(/https?:\/\/[^\/]*\brutube.ru\/video\/(\w+)/);
      if (urlMatch) {
        editor.insert("[rutube]" + urlMatch[1] + "[/rutube]");
        return;
      }
      //---------------------------------------------------------------/

      // No match.
      editor.insert(url);
    });
  },
  txtExec: function (caller) {
    var editor = this;

    editor.commands.video._dropDown(editor, caller, function (url) {
      var urlMatch;

      // Check for video file URLs.
      urlMatch = url.match(/\.(3gp|m4v|m4p|mp4|mpeg|mpg|mov|ogg|ogv|webm)$/);

      if (urlMatch) {
        editor.insert("[video]" + url + "[/video]");
        return;
      }

      // Check for audio file URLs.
      urlMatch = url.match(/\.(aac|flac|m4a|mp3|oga|wav)$/);

      if (urlMatch) {
        editor.insert("[audio]" + url + "[/audio]");
        return;
      }

      // Check for YouTube URLs.
      urlMatch = url.match(/https?:\/\/[^\/]*\b(?:youtube\.com|youtu\.be)\//);

      if (urlMatch) {
        urlMatch = url.match(
          /(?:v=|v\/|embed\/|youtu.be\/)?([a-zA-Z0-9_-]{11})/
        );

        if (urlMatch) {
          editor.insert("[youtube]" + urlMatch[1] + "[/youtube]");
        } else {
          editor.insert(url);
        }

        return;
      }

      // Check for Vimeo URLs.
      urlMatch = url.match(
        /https?:\/\/[^\/]*\bvimeo\.com\/(?:[^\/\d]*\/)?(\d+)/
      );

      if (urlMatch) {
        editor.insert("[vimeo]" + urlMatch[1] + "[/vimeo]");
        return;
      }

      // Check for RuTube URLs. ---------------------------------------/
      urlMatch = url.match(/https?:\/\/[^\/]*\brutube.ru\/video\/(\w+)/);

      if (urlMatch) {
        editor.insert("[rutube]" + urlMatch[1] + "[/rutube]");
        return;
      }
      //---------------------------------------------------------------/

      // No match.
      editor.insert(url);
    });
  },
});
