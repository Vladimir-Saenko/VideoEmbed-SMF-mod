<?php

/*******************************************************************************
 * Video Embed
 *
 * A modification for SMF 2.1 that expands support for embedding videos from
 * video hosting sites.
 *
 * Copyright (c) 2023 Jon Stovell
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 ******************************************************************************/

if (!defined('SMF'))
	die('No direct access...');

/**
 * Adds parsing instructions to parse_bbc()
 *
 * Called by:
 *      integrate_bbc_codes
 */
function videoembed_bbc_codes(&$codes, &$no_autolink_tags)
{
	// Backward compatibility with other YouTube mods.
	$yt_exists = in_array('yt', array_column($codes, 'tag'));

	foreach ($codes as &$code)
	{
		if ($code['tag'] === 'youtube')
		{
			// This adds support for full YouTube URLs inside the BBCode.
			if (!isset($code['validate']))
			{
				$code['validate'] = function (&$tag, &$data, $disabled)
				{
					$parsedurl = parse_url($data);

					if (isset($parsedurl['host']) && preg_match('~\byoutu(?>\.be|be(?>-nocookie)?\.com)$~', $parsedurl['host']))
					{
						if (!empty($parsedurl['query']))
						{
							foreach (preg_split('~(?=\w+=)~', $parsedurl['query']) as $query_param)
							{
								if (strpos($query_param, 'v=') === 0)
								{
									$data = substr($query_param, 2);
									break;
								}
							}
						}
						elseif (!empty($parsedurl['path']))
						{
							$data = $parsedurl['path'];
						}
					}
				};
			}

			// Allow (but ignore) parameters supported by some older YouTube mods.
			if (!isset($code['parameters']))
			{
				$code['parameters'] = array(
					'width' => array('optional' => true, 'match' => '(\d+)'),
					'height' => array('optional' => true, 'match' => '(\d+)'),
					'autoplay' => array('optional' => true, 'match' => '(1|yes|on|true)'),
					'color' => array('optional' => true, 'match' => '(red|white)'),
					'theme' => array('optional' => true, 'match' => '(light|dark)'),
					'loop' => array('optional' => true, 'match' => '(1|yes|on|true)'),
					'start' => array('optional' => true, 'match' => '(\d+|\d+\:\d+)'),
					'end' => array('optional' => true, 'match' => '(\d+|\d+\:\d+)'),
					'privacy' => array('optional' => true, 'match' => '(1|yes|on|true)'),
					'controls' => array('optional' => true, 'match' => '(0|no|off|false|hide)'),
					'showinfo' => array('optional' => true, 'match' => '(0|no|off|false|hide)'),
				);
			}

			// Support 'yt' as an alias of 'youtube' for compatibility with older mods.
			if (!$yt_exists)
			{
				$yt = $code;
				$yt['tag'] = 'yt';
				$codes[] = $yt;
			}
		}
	}

	// Add Vimeo BBCode.
	$codes[] = array(
		'tag' => 'vimeo',
		'type' => 'unparsed_content',
		// These unused parameters are included only for compatibility with older mods.
		'parameters' => array(
			'width' => array('optional' => true, 'match' => '(\d+)'),
			'frameborder' => array('optional' => true, 'match' => '(\d+)'),
		),
		'content' => '<div class="videocontainer"><div><iframe frameborder="0" src="https://player.vimeo.com/video/$1?title=0&amp;byline=0&amp;autopause=0&amp;badge=0" data-vimeo-id="$1" allowfullscreen loading="lazy"></iframe></div></div>',
		'disabled_content' => '<a href="https://vimeo.com/$1" target="_blank" rel="noopener">https://vimeo.com/$1</a>',
		'block_level' => true,
	);

	// Add RuTube BBCode.
	$codes[] = array(
		'tag' => 'rutube',
		'type' => 'unparsed_content',
		// These unused parameters are included only for compatibility with older mods.
		'parameters' => array(
			'width' => array('optional' => true, 'match' => '(\d+)'),
			'frameborder' => array('optional' => true, 'match' => '(\d+)'),
		),
		'content' => '<div class="videocontainer"><div><iframe frameborder="0" src="https://rutube.ru/play/embed/$1?title=0&amp;byline=0&amp;autopause=0&amp;badge=0" data-rutube-id="$1" allowfullscreen loading="lazy"></iframe></div></div>',
		'disabled_content' => '<a href="https://rutube.ru/play/embed/$1" target="_blank" rel="noopener">https://rutube.ru/play/embed/$1</a>',
		'block_level' => true,
	);

	// Add BBCode for video files from any source.
	$codes[] = array(
		'tag' => 'video',
		'type' => 'unparsed_content',
		'content' => '<div class="videocontainer"><div><video controls preload="metadata" src="$1" playsinline style="background-color: black;"><a href="$1" class="bbc_link" target="_blank" rel="noopener">$1</a></video></div></div>',
		'disabled_content' => '<a href="$1" class="bbc_link" target="_blank" rel="noopener">$1</a>',
		'validate' => function(&$tag, &$data, $disabled)
		{
			global $boardurl;

			$allowed_file_extensions = array(
				'3gp', 'aac', 'flac', 'm4a', 'm4v', 'm4p', 'mp3', 'mp4',
				'mpeg', 'mpg', 'mov', 'oga', 'ogg', 'ogv', 'wav', 'webm',
			);

			$parsedurl = parse_url($data);

			if (empty($parsedurl['host']) || empty($parsedurl['path']))
			{
				$tag['content'] = '$1';
				return;
			}

			if ($parsedurl['host'] === parse_url($boardurl, PHP_URL_HOST))
			{
				$tag['content'] = str_replace(' target="_blank" rel="noopener"', '', $tag['content']);
				$tag['disabled_content'] = str_replace(' target="_blank" rel="noopener"', '', $tag['disabled_content']);
			}

			$pathinfo = pathinfo($parsedurl['path']);

			if (empty($pathinfo['extension']) || !in_array(strtolower($pathinfo['extension']), $allowed_file_extensions))
			{
				$tag['content'] = $tag['disabled_content'];
				return;
			}
		},
		'block_level' => true,
	);

	// Add BBCode for audio files from any source.
	$codes[] = array(
		'tag' => 'audio',
		'type' => 'unparsed_content',
		'content' => '<audio controls preload="none" src="$1" class="bbc_audio" style="vertical-align: middle; max-width: 100%; width: 400px; display: block;"><a href="$1" class="bbc_link" target="_blank" rel="noopener">$1</a></audio>',
		'disabled_content' => '<a href="$1" class="bbc_link" target="_blank" rel="noopener">$1</a>',
		'validate' => function(&$tag, &$data, $disabled)
		{
			global $boardurl;

			$allowed_file_extensions = array(
				'3gp', 'aac', 'flac', 'm4a', 'mp3', 'mp4', 'mpeg', 'mpg',
				'oga', 'ogg', 'wav', 'webm',
			);

			$parsedurl = parse_url($data);

			if (empty($parsedurl['host']) || empty($parsedurl['path']))
			{
				$tag['content'] = '$1';
				return;
			}

			if ($parsedurl['host'] === parse_url($boardurl, PHP_URL_HOST))
			{
				$tag['content'] = str_replace(' target="_blank" rel="noopener"', '', $tag['content']);
				$tag['disabled_content'] = str_replace(' target="_blank" rel="noopener"', '', $tag['disabled_content']);
			}

			$pathinfo = pathinfo($parsedurl['path']);

			if (empty($pathinfo['extension']) || !in_array(strtolower($pathinfo['extension']), $allowed_file_extensions))
			{
				$tag['content'] = $tag['disabled_content'];
				return;
			}
		},
		'block_level' => true,
	);
}

/**
 * Tells SCEditor to permit iframes from video hosting sites beyond YouTube.
 *
 * Called by:
 *      integrate_sceditor_options
 */
function videoembed_sceditor_options(&$sce_options)
{
	$sce_options['allowedIframeUrls'] = array(
		'https://player.vimeo.com/video/',
	);
	$sce_options['allowedIframeUrls'] = array(
		'https://rutube.ru/play/embed/',
	);
}

/**
 * Replaces YouTube editor toolbar button with generic Video toolbar button.
 *
 * Called by:
 * 		integrate_bbc_buttons
 */
function videoembed_bbc_buttons(&$bbc_tags, &$editor_tag_map)
{
	global $context, $editortxt, $txt;

	$temp = array();

	foreach ($bbc_tags as $section => $buttons)
	{
		$temp[$section] = array();
		foreach ($buttons as $button)
		{
			if (isset($button['code']) && $button['code'] === 'youtube')
			{
				$temp[$section][] = array(
					'image' => 'film-youtube',
					'code' => 'video',
					'description' => str_ireplace('YouTube', 'Youtube, Vimeo ' . $txt['or'] . ' RuTube', $editortxt['insert_youtube_video']),
				);
			}
			else
				$temp[$section][] = $button;
		}
	}
	$bbc_tags = $temp;

	loadJavaScriptFile('videoembed.js', array('minimize' => true), 'smf_videoembed');
}

/**
 * Mentions who made this thing.
 *
 * Called by:
 * 		integrate_credits
 */
function videoembed_credits()
{
	global $context;
	$context['copyrights']['mods'][] = 'Video Embed by Jon &quot;Sesquipedalian&quot; Stovell &copy; 2023';
}